function ScanRabiWithMsGSC(varargin)

dic=Dictator.me;

PulseTime=1:1:80;
detunning =0;
RabiMode=0;
mode2Cool=[1 2];
%--------options------------- 
for i=1:2:size(varargin,2)
   switch lower(char(varargin(i)))
       case 'rabimode'
           RabiMode=varargin{i+1};
           if RabiMode>0
              detunning=-dic.vibMode(RabiMode).freq;
           else
              detunning=0; 
           end
       case 'gscmode'
           mode2Cool=varargin{i+1};
       case 'duration'
           PulseTime=varargin{i+1};
   end; %switch
end;%for loop

%-------------- Set GUI figures ---------------------
InitializeAxes (dic.GUI.sca(1),'Photons #','Cases Counted #','Fluorescence Histogram',...
                [0 dic.maxPhotonsNumPerReadout],[],0);

lines =InitializeAxes (dic.GUI.sca(9),...
    'Pulse Time[\mus]','Dark Counts %','Rabi Scan',...
    [PulseTime(1) PulseTime(end)],[0 100],3);

set(lines(1),'Marker','.','MarkerSize',10,'Color','b');
set(lines(2),'Marker','.','MarkerSize',10,'Color','r');
set(lines(3),'Marker','.','MarkerSize',10,'Color','k');
%-------------- main scan loop ---------------------
dark = zeros(size(PulseTime));
for index1 = 1:length(PulseTime)
    if dic.stop
        return
    end
    r=experimentSequence(PulseTime(index1),dic.updateF674+detunning,mode2Cool);
    dic.GUI.sca(1); %get an axis from Dictator GUI to show data
    hist(r,0:1:(1.8*dic.maxPhotonsNumPerReadout));

    dark(index1,1)=sum(r<dic.darkCountThreshold)/length(r)*100;
    dark(index1,2)=sum((r>dic.darkCountThreshold)&(r<dic.TwoIonsCountThreshold))/length(r)*100;
    dark(index1,3)=sum(r>dic.TwoIonsCountThreshold)/length(r)*100;
    
    AddLinePoint(lines(1),PulseTime(index1),dark(index1,1));
    AddLinePoint(lines(2),PulseTime(index1),dark(index1,2));
    AddLinePoint(lines(3),PulseTime(index1),dark(index1,3));
    pause(0.1);
end
%--------------- Save data ------------------
if (dic.AutoSaveFlag)
    destDir=dic.saveDir;
    thisFile=[mfilename('fullpath') '.m' ];
    [filePath fileName]=fileparts(thisFile);
    scriptText=fileread(thisFile);
    showData='figure;plot(PulseTime,dark);xlabel(''Pulse Time[\mus]'');ylabel(''dark[%]'');';
    saveFileName=fullfile(destDir ,[fileName datestr(now,'-ddmmmyy-HHMMSS')]);
    dicParameters=dic.getParameters;
    save(saveFileName,'PulseTime','dark','RabiMode','mode2Cool','showData','dicParameters','scriptText');
    disp(['Save data in : ' saveFileName]);
end 
% --------------------------------------------------------------------
    function r=experimentSequence(pulseTime,freq,Mode2Cool)

        prog=CodeGenerator;
        prog.GenDDSPullParametersFromBase;
        prog.GenSeq(Pulse('ExperimentTrigger',0,50));
        prog.GenSeq(Pulse('674DDS1Switch',0,-1,'freq',freq,'amp',100));
        % Doppler coolng
        prog.GenSeq(Pulse('OffRes422',0,100));%turn off cooling
        prog.GenSeq(Pulse('OnResCooling',0,dic.Tcooling));
        
        % ---------continuous GSC -----------
        SeqGSC=[]; N=4; Tstart=2;
        for mode=Mode2Cool
            SeqGSC=[SeqGSC,Pulse('NoiseEater674',Tstart,dic.vibMode(mode).coolingTime/N),...
                           Pulse('674DDS1Switch',Tstart,dic.vibMode(mode).coolingTime/N,...
                                 'freq',dic.updateF674+dic.vibMode(mode).freq+dic.acStarkShift674)];
            Tstart=2+Tstart+dic.vibMode(mode).coolingTime/N;
        end
        prog.GenSeq([Pulse('Repump1033',0,0), Pulse('OpticalPumping',0,0)]);
        prog.GenRepeatSeq(SeqGSC,N);
        prog.GenSeq([Pulse('Repump1033',dic.T1033,-1), Pulse('OpticalPumping',dic.T1033,-1)]);
        % pulsed GSC
        for mode=fliplr(Mode2Cool)
        prog.GenRepeatSeq([Pulse('NoiseEater674',2,dic.vibMode(mode).coldPiTime),...
                           Pulse('674DDS1Switch',2,dic.vibMode(mode).coldPiTime,'freq',dic.updateF674+dic.vibMode(mode).freq),...
                           Pulse('Repump1033',dic.vibMode(mode).coldPiTime,dic.T1033),...
                           Pulse('OpticalPumping',dic.vibMode(mode).coldPiTime+dic.T1033,dic.Toptpump)],2);                          
        end
        
        %----------sideband Shelving ------------
%         prog.GenSeq([Pulse('NoiseEater674',2,pulseTime),...
%                      Pulse('674DDS1Switch',2,pulseTime,'freq',freq)]);
        prog.GenSeq([Pulse('674PulseShaper',0,-1),...
                     Pulse('674PulseShaper',5,pulseTime),...
                     Pulse('674DDS1Switch',5,pulseTime+5,'freq',freq)]);
%         detection
        prog.GenSeq([Pulse('OnRes422',0,dic.TDetection) Pulse('PhotonCount',0,dic.TDetection)]);
        %resume cooling
        prog.GenSeq(Pulse('Repump1033',0,dic.T1033));
        prog.GenSeq(Pulse('OffRes422',0,0));
        prog.GenSeq(Pulse('674PulseShaper',0,0));
        prog.GenFinish;

        dic.com.UploadCode(prog);
        dic.com.UpdateFpga;
        dic.com.WaitForHostIdle; % wait until host finished it last task
        rep=200;
        dic.com.Execute(rep);
        dic.com.WaitForHostIdle;
        r = dic.com.ReadOut(rep);
        r = r(2:end);
    end

end