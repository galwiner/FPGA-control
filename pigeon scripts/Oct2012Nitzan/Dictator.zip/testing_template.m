function testing_template
dic=Dictator.me;
    prog=CodeGenerator; 
    prog.GenDDSPullParametersFromBase;
    prog.GenSeq(Pulse('ExperimentTrigger',0,50));
 
    prog.GenSeq([Pulse('674DDS1Switch',0,dic.T674+20) Pulse('674PulseShaper',10,dic.T674)]);
    prog.GenSeq([Pulse('OnRes422',0,dic.TDetection) Pulse('PhotonCount',0,dic.TDetection)]);
    prog.GenFinish;
    %prog.DisplayCode;

dic.com.UploadCode(prog);
dic.com.UpdateFpga;

rep=300;
while (~dic.stop)
    dic.com.Execute(rep);
    dic.com.WaitForHostIdle;
    r=dic.com.ReadOut(-1);
    pause(0.1);
end

end


