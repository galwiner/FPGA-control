function PhotonAtomCorrelation
dic=Dictator.me;

PulseTime=0.2:0.05:1.5;

%-------------- set GUI ---------------
lines =InitializeAxes (dic.GUI.sca(9),'excitation time [\mus]','H pol','',...
                       [PulseTime(1) PulseTime(end)],[],2);
set(lines(1),'XData',[],'YData',[],'Color','b',...
          'LineWidth',0.5,'Marker','.','MarkerSize',10);
set(lines(2),'XData',[],'YData',[],'Color','r',...
          'LineWidth',0.5,'Marker','.','MarkerSize',10);

%-------------- main scan loop -----------
for ind1 =1:length(PulseTime)
    r=experimentSeqeunce(PulseTime(ind1));
    photon=1+(r(1:3:end)==1);
    ion=1+(r(3:3:end)>dic.darkCountThreshold);
    DensityM=zeros(2,2);
    for ind=1:length(ion)
        DensityM(ion(ind),photon(ind))=DensityM(ion(ind),photon(ind))+1;
    end
    AddLinePoint(lines(1),PulseTime(ind1),sum(photon-1));
    AddLinePoint(lines(2),PulseTime(ind1),sum(ion-1));

    disp(DensityM)
    expResult(ind1,:)=r;
end

%------------ Save data ------------------
if (dic.AutoSaveFlag)
    destDir=dic.saveDir;
    thisFile=[mfilename('fullpath') '.m' ];
    [filePath fileName]=fileparts(thisFile);
    scriptText=fileread(thisFile);
    showData=['disp(''no disp for this file'')'];
    saveFileName=fullfile(destDir ,[fileName datestr(now,'-ddmmmyy-HHMMSS')]);
    dicParameters=dic.getParameters;
    save(saveFileName,'expResult','PulseTime','showData','dicParameters','scriptText');
    disp(['Save data in : ' saveFileName]);
end 

% ------------------------- Experiment sequence ------------------------------------    
    function [r]=experimentSeqeunce(pTime) 
    prog=CodeGenerator; 
    prog.GenDDSPullParametersFromBase;
    prog.GenSeq(Pulse('ExperimentTrigger',0,50));
    prog.GenSeq(Pulse('RFDDS2',0,-1,'freq',dic.FRF));
    prog.GenSeq( Pulse('674DDS1Switch',0,-1,'freq',dic.updateF674,'amp',100) );
    %initialization
    prog.GenSeq(Pulse('OffRes422',0,100));
    prog.GenSeq(Pulse('OnResCooling',0,dic.Tcooling));
    prog.GenSeq(Pulse('OpticalPumping',0,dic.Toptpump));
    % Photon scattering 
    prog.GenRegOp('RegB=',0);
    prog.GenRegOp('RegC=',0);
    prog.GenRepeat
        % Reset pulse
         prog.GenSeq([Pulse('Repump1092',2,1),...
                           Pulse('OpticalPumping',2,5),...
                           Pulse('RFDDS2',7,dic.TimeRF-1),...
                           Pulse('OpticalPumping',18,pTime),...
                           Pulse('PMTsAccumulate',18.5,1.5)]);
    prog.GenRegOp('RegC=+1',0);
    prog.GenRepeatEnd('RegB>0');
    % A photon was measured
    prog.GenRegOp('FIFO<-RegB',0);
    prog.GenPause(0.1);
    prog.GenRegOp('FIFO<-RegC',0);
    % Ion detection 
    prog.GenSeq(Pulse('674DDS1Switch',0,dic.T674));
    prog.GenSeq([Pulse('Repump1092',0,0)...
                 Pulse('OnRes422',0,dic.TDetection)...
                 Pulse('PhotonCount',0,dic.TDetection)]);
    prog.GenSeq(Pulse('OffRes422',0,0));
    prog.GenFinish;


        %prog.DisplayCode;

        % FPGA/Host control
        n=dic.com.UploadCode(prog);
        dic.com.UpdateFpga;
        dic.com.WaitForHostIdle;
        rep=300;
        dic.com.Execute(rep);
        dic.com.WaitForHostIdle;
        r=dic.com.ReadOut(-1);        
    end
end


