function [Nbar,Omega,y]=fitNbar2CarrierRabi(T,Pup,Faxial,BeamAngle)
%calc Rabi flopping with thermal state distribution
% t [S]

h_bar=1.05e-34;     %[J*s]
k_674=2*pi/674e-9;   %[1/m]
m_Sr=88*1.6e-27;        %[Kg]
omega0=2*pi*1e6*Faxial; %[rad/S]
eta=k_674*cos(BeamAngle)*sqrt(h_bar/2/m_Sr/omega0);

Ymodel=@(par,t)... 
    1/2*(1- (cos(2*par(1).*t)+2*par(1).*t.*(eta^2.*par(2)).*sin(2*par(1)*t))...
    ./(1+(2*par(1)*t*(eta^2.*par(2))).^2));

options=optimset('Display','off');
[m mind]=max(Pup);
omega0=pi/2/T(mind);
[fitpar]=lsqcurvefit(Ymodel,[omega0 20],T,Pup,[1e4 1],[2e6 50],options);
Omega=fitpar(1);
Nbar=fitpar(2);
y=Ymodel(fitpar,T);
end
